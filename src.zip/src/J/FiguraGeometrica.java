package J;

public abstract class FiguraGeometrica {
    public FiguraGeometrica(){}

    public abstract boolean intercecao(Trajectory trajetoria);

    public abstract void check();
}
