package G;

public abstract class FiguraGeometrica {
    public FiguraGeometrica(String s){}

    public abstract boolean intercecao(Trajectory trajetoria);

    public abstract void check();
}
